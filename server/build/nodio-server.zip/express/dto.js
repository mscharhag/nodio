'use strict';

var convert = rek('converter');

module.exports = function() {
	return function(req, res, next) {
		res.dto = function(obj) {
			res.json(convert(obj));
		}
		res.header('Access-Control-Allow-Origin', '*' /* 'http://192.168.1.8:3000' */)
		res.header('Access-Control-Allow-Methods', 'POST, GET')
		next();
	}
}