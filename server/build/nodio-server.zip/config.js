'use strict';

var app = rek('app');

var config = module.exports = {};

config.trackDirectory = 'test/files'

config.playerUrl = '/player'
config.tracksUrl = '/tracks'
config.locationsUrl = '/locations'